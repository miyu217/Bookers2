# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '4946520e03d7a6969843a88cc996c2020b8a41e86dde00dad7eb95b676a55c1f199fd060d2de9bd0f17d92b84205be74f8e0b60b790cbdf169815471c4776fc7'
